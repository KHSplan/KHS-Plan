package com.khsplan.khsplan;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
