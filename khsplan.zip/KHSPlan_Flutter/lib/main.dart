import 'package:flutter/material.dart';
import 'package:username_gen/username_gen.dart';


void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Superhelden Namen',
      home: NamenGenerator(),
    );
  }
}

class NamenGenerator extends StatefulWidget {

  @override
  State<StatefulWidget> createState() => _Name();
}

class _Name extends State<NamenGenerator> {
  final _namen = <String>[];
  final _hearted = <String>{};
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title:Text('Welcome to my Superhero Picker')
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    return ListView.builder(
        padding: EdgeInsets.all(16),
        itemBuilder: (context, i) {
          if(i.isOdd) {
            return Divider();
          }
          if(i ~/ 2 >= _namen.length) {
            _namen.addAll(_usernameCreator());
          }
          return _buildRow(_namen[i~/2]);
        }
    );
  }
  Iterable<String> _usernameCreator() {
    List<String> myNames = [
      _randomUsername(),
      _randomUsername(),
      _randomUsername(),
      _randomUsername(),
    ];
    return myNames;
  }
  String _randomUsername(){
    String _username = UsernameGen.generateWith(
        data: UsernameGenData(names: ['Hans', 'Günther', 'Max'],
            adjectives: ['Lauter', 'Blauer', 'Kalter', 'Schneller']),
        seperator: '-'
    );
    return _username;
  }

  Widget _buildRow(String name) {
    final _markedFav = _hearted.contains(name);
    return ListTile(
      title: Text(name),
      trailing: Icon(
        _markedFav ? Icons.favorite : Icons.favorite_border,
        color: _markedFav ? Colors.red : null,
      ),
      onTap: () {
        setState(() {
          _markedFav ? _hearted.remove(name) : _hearted.add(name);
        });
      },
      onLongPress: () {
        _pushExaple(name);
        },
    );
  }

  void _pushExaple(String name) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (BuildContext context){
        final _name = name;
        return Scaffold(
          appBar: AppBar(
            title: Text(_name),
          ),
          body: Center(
            child: Image.network('https://picsum.photos/200/300')
          ),
        );
      }),
    );
  }
}